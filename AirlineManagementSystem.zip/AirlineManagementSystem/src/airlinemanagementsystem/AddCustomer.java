package airlinemanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddCustomer extends JFrame implements ActionListener {

    private JTextField tfname, tfphone, tfaadhar, tfnationality, tfaddress;
    private JRadioButton rbmale, rbfemale;
    private JButton save;

    public AddCustomer() {
        setTitle("Add Customer Details");
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("ADD CUSTOMER DETAILS");
        heading.setBounds(220, 20, 500, 35);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 32));
        heading.setForeground(Color.BLUE);
        add(heading);

        addLabel("Name", 60, 80);
        tfname = addTextField(220, 80);

        addLabel("Nationality", 60, 130);
        tfnationality = addTextField(220, 130);

        addLabel("Aadhar Number", 60, 180);
        tfaadhar = addTextField(220, 180);

        addLabel("Address", 60, 230);
        tfaddress = addTextField(220, 230);

        addLabel("Gender", 60, 280);
        rbmale = new JRadioButton("Male");
        rbfemale = new JRadioButton("Female");

        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(rbmale);
        genderGroup.add(rbfemale);

        rbmale.setBounds(220, 280, 70, 25);
        rbfemale.setBounds(300, 280, 70, 25);
        rbmale.setBackground(Color.WHITE);
        rbfemale.setBackground(Color.WHITE);
        add(rbmale);
        add(rbfemale);

        addLabel("Phone", 60, 330);
        tfphone = addTextField(220, 330);

        save = new JButton("SAVE");
        save.setBounds(220, 380, 150, 30);
        save.setBackground(Color.BLACK);
        save.setForeground(Color.WHITE);
        save.addActionListener(this);
        add(save);

        ImageIcon image = new ImageIcon(ClassLoader.getSystemResource("airlinemanagementsystem/icons/emp.png"));
        JLabel lblimage = new JLabel(image);
        lblimage.setBounds(450, 80, 280, 400);
        add(lblimage);

        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, 150, 25);
        label.setFont(new Font("Tahoma", Font.PLAIN, 16));
        add(label);
    }

    private JTextField addTextField(int x, int y) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, 150, 25);
        add(textField);
        return textField;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String name = tfname.getText().trim();
        String nationality = tfnationality.getText().trim();
        String phone = tfphone.getText().trim();
        String address = tfaddress.getText().trim();
        String aadhar = tfaadhar.getText().trim();
        String gender = rbmale.isSelected() ? "Male" : (rbfemale.isSelected() ? "Female" : null);

        if (name.isEmpty() || nationality.isEmpty() || phone.isEmpty() || address.isEmpty() || aadhar.isEmpty() || gender == null) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!phone.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Invalid phone number! Must be 10 digits.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!aadhar.matches("\\d{12}")) {
            JOptionPane.showMessageDialog(this, "Invalid Aadhar number! Must be 12 digits.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
			saveCustomerDetails(name, nationality, phone, address, aadhar, gender);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    private void saveCustomerDetails(String name, String nationality, String phone, String address, String aadhar, String gender) throws Exception {
        String query = "INSERT INTO passenger (name, nationality, phone, address, aadhar, gender) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Conn conn = new Conn();
             PreparedStatement pst = conn.c.prepareStatement(query)) {

            pst.setString(1, name);
            pst.setString(2, nationality);
            pst.setString(3, phone);
            pst.setString(4, address);
            pst.setString(5, aadhar);
            pst.setString(6, gender);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Customer Details Added Successfully!");
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add customer.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error saving customer details.", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AddCustomer::new);
    }
}
