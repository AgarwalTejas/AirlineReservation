package airlinemanagementsystem;

import java.sql.ResultSet;

import javax.swing.table.TableModel;

public class DbUtils {

	public static TableModel resultSetToTableModel(ResultSet rs) {
		// TODO Auto-generated method stub
		return null;
	}

}
