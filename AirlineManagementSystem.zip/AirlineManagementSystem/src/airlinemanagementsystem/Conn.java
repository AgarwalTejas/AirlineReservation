package airlinemanagementsystem;
import java.lang.*;
import java.sql.*;

public class Conn implements AutoCloseable{
    
    Connection c;
    Statement s;
    
    public Conn() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql:///airlinemanagementsystem", "root", "Tejas5332");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}
}

